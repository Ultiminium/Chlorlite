orbcollector — built with CC.

Run:
  ./orbcollector

Everything the game needs is in this folder. The engine (renderer, audio,
input, physics) is compiled into the executable — no install required. Any
game data files live in ./assets and are found relative to the executable.

Target: linux
